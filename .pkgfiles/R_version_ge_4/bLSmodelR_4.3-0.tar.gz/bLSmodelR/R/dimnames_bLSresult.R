dimnames.bLSresult <- function(x){
	list(row.names(x), names(x))
}
