print.TDhead <- function(x,...){
	cat(paste0("\n",x,"\n"))
}
