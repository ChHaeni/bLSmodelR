calcC0 <- function(bw,kv=0.4,A=0.5){
	return(2*kv/A*(bw^4 + 1)/bw)
}
