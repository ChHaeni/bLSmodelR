

CalcSteps <- function(x){
	attr(x,"CalcSteps")
}
 
CatPath <- function(x){
	attr(x,"CatPath")
}

Catalogs <- function(x){
	attr(x,"Catalogs")
}

ModelInput <- function(x){
	attr(x,"ModelInput")
}


