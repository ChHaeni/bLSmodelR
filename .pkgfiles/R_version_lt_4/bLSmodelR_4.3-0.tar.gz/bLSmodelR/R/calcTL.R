calcTL <-
function(sigmaW,C0,epsilon){
return(2*sigmaW^2/(C0*epsilon))
}
