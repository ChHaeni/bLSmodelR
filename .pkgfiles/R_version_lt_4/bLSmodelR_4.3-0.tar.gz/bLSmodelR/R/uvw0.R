uvw0 <- function(x)attr(x,"uvw0")
