points.TDcat <- function(x,...){
	invisible(x[,points(x,y,...)])
}